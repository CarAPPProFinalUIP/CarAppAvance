package com.carapp.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.carapp.R;
import com.carapp.datosuser.Usuario;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            ((EditText) this.findViewById(R.id.userName)).clearComposingText();
            ((EditText) this.findViewById(R.id.password)).clearComposingText();
        } catch (Exception e) {
        }
        setContentView(R.layout.activity_main);
    }

    public void goRegister(View view) {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }

    public void goLogin(View view) {
        Usuario user = new Usuario();
        user.Autenticacion(((EditText)findViewById(R.id.userName)).getText().toString().trim(), view.getContext());

        if (user.verificacionLogin((EditText)findViewById(R.id.userName),
                (EditText)findViewById(R.id.password))) {
            Toast.makeText(getApplicationContext(), "Usuario " + user.getUserName() + " Ingresado", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, ReservationActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(getApplicationContext(), "Usuario/Clave Incorrecta", Toast.LENGTH_SHORT).show();
        }
    }
}
