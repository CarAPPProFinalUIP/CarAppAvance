package com.carapp;

import com.carapp.datosuser.Usuario;

public class Reserva {
    int ordenId;
    String dateCreacion;
    String dateUso;
    String dateVencimiento;
    Usuario cliente;
    String status;
    double precioTotal;

    public Reserva() {
        this.ordenId = 0;
        this.dateCreacion = "";
        this.dateUso = "";
        this.dateVencimiento = "";
        this.cliente = null;
        this.status = "";
        this.precioTotal = 0;
    }

    public int getOrdenId() {
        return ordenId;
    }

    public void setOrdenId(int ordenId) {
        this.ordenId = ordenId;
    }

    public String getDateCreacion() {
        return dateCreacion;
    }

    public void setDateCreacion(String dateCreacion) {
        this.dateCreacion = dateCreacion;
    }

    public String getDateUso() {
        return dateUso;
    }

    public void setDateUso(String dateUso) {
        this.dateUso = dateUso;
    }

    public String getDateVencimiento() {
        return dateVencimiento;
    }

    public void setDateVencimiento(String dateVencimiento) {
        this.dateVencimiento = dateVencimiento;
    }

    public Usuario getCliente() {
        return cliente;
    }

    public void setCliente(Usuario cliente) {
        this.cliente = cliente;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(double precioTotal) {
        this.precioTotal = precioTotal;
    }
}
