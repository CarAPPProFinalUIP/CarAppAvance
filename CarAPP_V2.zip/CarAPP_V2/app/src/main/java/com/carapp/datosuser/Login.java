package com.carapp.datosuser;

public class Login {

    private int pin;

    public Login() {

    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }
}
