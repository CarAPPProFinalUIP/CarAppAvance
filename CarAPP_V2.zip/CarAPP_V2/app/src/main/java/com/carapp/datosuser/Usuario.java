package com.carapp.datosuser;

import android.content.Context;
import android.widget.EditText;

import com.carapp.adapters.DataAccessImpl;

public class Usuario {

    private String userName;
    private String nombre;
    private String apellido;
    private String password;
    private String telefono;
    private String correo;
    private DataAccessImpl userDataAccess;

    public Usuario() {
        this.userName = "";
        this.nombre   = "";
        this.apellido = "";
        this.password = "";
        this.telefono = "";
        this.correo   = "";
        this.userDataAccess = new DataAccessImpl();
    }

    public Usuario(String userName, String nombre, String apellido,
                   String password, String telefono, String correo) {
        this.userName = userName;
        this.nombre   = nombre;
        this.apellido = apellido;
        this.password = password;
        this.telefono = telefono;
        this.correo   = correo;
        this.userDataAccess = new DataAccessImpl();
    }

    public String getUserName() {
        return userName;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getPassword() {
        return password;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void CrearUsuario(Context context) {
        userDataAccess.saveUserData(this, context);
    }

    public void Autenticacion(String userName, Context context) {
        this.userDataAccess = new DataAccessImpl();
        String[] userData = userDataAccess.getUserData(userName, context);
        this.setDataString(userData);
    }

    public boolean verificacionLogin(EditText username, EditText password) {
        return (this.userName.equals(username.getText().toString().trim()) &&
                this.password.equals(password.getText().toString().trim()));
    }

    public String getDataString() {
        return this.userName + "|" + this.nombre + "|" + this.apellido + "|" +
               this.password + "|" + this.telefono + "|" + this.correo;
    }

    public void setDataString(String[] data) {
        this.userName = data[0];
        this.nombre   = data[1];
        this.apellido = data[2];
        this.password = data[3];
        this.telefono = data[4];
        this.correo   = data[5];
   }
}
