package com.carapp.datosuser;

public class Registro {

    private String[] preguntas;

    public void Registro() {

    }

    public void Restore() {

    }

}
